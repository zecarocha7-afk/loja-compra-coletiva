import React from 'react';
import { motion } from 'motion/react';
import { Factory, Star, ExternalLink, ShieldCheck, Award } from 'lucide-react';
import { VENDORS } from '../../constants';

export default function ManufacturersView() {
  return (
    <div className="p-4 lg:p-8">
      <div className="mb-10">
        <h2 className="text-2xl font-black text-white uppercase tracking-widest flex items-center gap-3">
           <div className="w-2 h-8 bg-industrial-gold"></div>
           Fornecedores Oficiais
        </h2>
        <p className="text-[11px] font-mono text-gray-500 uppercase tracking-tighter mt-1">Fabricantes Homologados pela Instituição</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {VENDORS.map((vendor, index) => (
          <motion.div
            key={vendor.id}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: index * 0.1 }}
            className="bg-industrial-surface border border-industrial-outline metallic-border p-6 group flex gap-6"
          >
            <div className="w-24 h-24 bg-white rounded bg-contain bg-center bg-no-repeat p-4 flex-shrink-0" style={{ backgroundImage: `url(${vendor.logo})` }} />
            
            <div className="flex-1 space-y-3">
              <div className="flex items-start justify-between">
                <div>
                  <h3 className="text-lg font-black text-white uppercase tracking-wider group-hover:text-industrial-gold transition-colors">{vendor.name}</h3>
                  <div className="flex items-center gap-2 mt-1">
                    <div className="flex text-industrial-gold">
                      {[...Array(5)].map((_, i) => (
                        <Star key={i} className={`w-3 h-3 ${i < Math.floor(vendor.rating) ? 'fill-current' : 'opacity-30'}`} />
                      ))}
                    </div>
                    <span className="text-[10px] font-mono text-gray-600">{vendor.rating} / 5.0</span>
                  </div>
                </div>
                <div className="bg-industrial-gold/10 px-2 py-1 border border-industrial-gold/20 flex items-center gap-1.5">
                   <ShieldCheck className="w-3 h-3 text-industrial-gold" />
                   <span className="text-[9px] font-black text-industrial-gold uppercase">Homologado</span>
                </div>
              </div>

              <p className="text-xs text-gray-400 leading-relaxed">
                {vendor.description}
              </p>

              <div className="flex items-center justify-between pt-4 border-t border-industrial-outline/50">
                <div className="flex items-center gap-2">
                   <Award className="w-4 h-4 text-industrial-gold" />
                   <span className="text-[10px] font-mono text-gray-400 uppercase tracking-wider">Qualidade: Premium</span>
                </div>
                <a 
                  href={vendor.catalogUrl} 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="bg-industrial-red/10 hover:bg-industrial-red text-industrial-red hover:text-white border border-industrial-red/20 hover:border-industrial-red px-4 py-2 text-[10px] font-black uppercase tracking-[0.2em] transition-all flex items-center gap-2 group/link"
                >
                   VER CATÁLOGO 
                   <ExternalLink className="w-3 h-3 group-hover/link:translate-x-0.5 transition-transform" />
                </a>
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}
